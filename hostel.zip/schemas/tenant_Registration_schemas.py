from sqlalchemy import Column, Integer, String, Boolean, Enum, DECIMAL, ForeignKey, LargeBinary, Date
from database.database import Base
import enum
from models.hostel_registration_models import GenderEnum

import uuid
class GovtIDEnum(str, enum.Enum):
    Aadhar = "Aadhar"
    PAN = "PAN"
    VoterID = "VoterID"

class NecessityEnum(str, enum.Enum):
    Student = "Student"
    Employee = "Employee"
    SelfEmployment = "Self Employee"
    Other = "Other"

class FoodEnum(str, enum.Enum):
    Veg = "Veg"
    NonVeg = "Non Veg"
    Both = "Both"
class RoomEnum(str, enum.Enum):
    AC = "AC"
    NONAC = "Non AC"

class TenantRegistration(Base):
    __tablename__ = "tenant_registration_form"
    __table_args__ = {"schema": "tenant"}
    hostel_id = Column(String(225), unique=True, primary_key=True)
    tenant_id = Column(String(225), primary_key=True)
    first_name = Column(String(20), nullable=False)
    last_name = Column(String(20), nullable=False)
    phone_number = Column(String(15), nullable=False)
    father_name = Column(String(50))
    father_phone_number = Column(String(50))
    gender = Column(Enum(GenderEnum), nullable=False)
    date_of_birth = Column(Date, nullable=False)
    address = Column(String(100))
    house_no = Column(String(50))
    street = Column(String(50))
    colony = Column(String(50))
    landmark = Column(String(50))
    city = Column(String(50))
    state = Column(String(50))
    pincode = Column(String(20))
    country = Column(String(20), default="India")
    govt_id_type = Column(Enum(GovtIDEnum), nullable=False)
    govt_id_file = Column(LargeBinary, nullable=True)
    govt_id_number = Column(String(50), nullable=False)
    necessity = Column(Enum(NecessityEnum), nullable=False)
    emergency_contact = Column(String(15))
    food_preference = Column(Enum(FoodEnum), nullable=False)
    room_type = Column(Enum(RoomEnum), nullable=False)

class TenantStudent(Base):
    __tablename__ = "tenant_student"
    __table_args__ = {"schema": "tenant"}
    tenant_id = Column(String(225), ForeignKey("tenant.tenant_registration_form.tenant_id"), primary_key=True)
    studying_at = Column(String(200), nullable=False)
    student_id_number = Column(String(50), nullable=False)
    id_card_photo = Column(LargeBinary)
    college_address = Column(String(50))
    city = Column(String(100))
    pincode = Column(String(10))
    phone_number = Column(String(15))
  
class TenantEmployee(Base):
    __tablename__ = "tenant_employee"
    __table_args__ = {"schema": "tenant"}
    tenant_id = Column(String(225), ForeignKey("tenant.tenant_registration_form.tenant_id", ondelete="CASCADE"), primary_key=True)
    company_name = Column(String(200), nullable=False)
    employee_id_number = Column(String(50), nullable=False)
    id_card_image = Column(LargeBinary)
    address = Column(String(50))
    city = Column(String(100))
    pincode = Column(String(10))
    phone_number = Column(String(15))

   

class TenantSelfEmployed(Base):
    __tablename__ = "tenant_self_employed"
    __table_args__ = {"schema": "tenant"}
    tenant_id = Column(String(225), ForeignKey("tenant.tenant_registration_form.tenant_id", ondelete="CASCADE"), primary_key=True)
    occupation = Column(String(200), nullable=False)
    alternate_number = Column(String(15))
    

class TenantOther(Base):
    __tablename__ = "tenant_other"
    __table_args__ = {"schema": "tenant"}
    tenant_id = Column(String(225), ForeignKey("tenant.tenant_registration_form.tenant_id", ondelete="CASCADE"), primary_key=True)
    description = Column(String(500))
    phone_number = Column(String(15))